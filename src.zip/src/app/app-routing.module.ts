import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {StudentNewListComponent} from './student-new-list/student-new-list.component';
import {StudentNewListDetailsComponent} from './student-new-list-details/student-new-list-details.component';
import{LoginComponent} from './login/login.component';
import {CustomErrorComponent} from './custom-error/custom-error.component';

const routes: Routes = [
 
  {
    path:'StudentNewLink', component:StudentNewListComponent
  },
  {
    path:'StudentNewLinkDetails', component: StudentNewListDetailsComponent
  },
  {
    path:'Login', component:LoginComponent
  },
  {
    path:'', redirectTo:'Login', pathMatch:'full'
  },
  {
    path:'**', component:CustomErrorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
