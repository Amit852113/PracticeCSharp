import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-if-statement',
  templateUrl: './if-statement.component.html',
  styleUrls: ['./if-statement.component.css']
})
export class IfStatementComponent {
 isValid : boolean=true;
 changeData(valid : boolean){
 this.isValid=valid;
 }
}
