import{Pipe,PipeTransform} from'@angular/core';

@Pipe({
name: 'MyTitle'
})

export class CustomPipeComponent implements PipeTransform {

transform(name:string, gender :string):string {
  if(gender.toLowerCase() =="male")
      return "Mr. "+ name;
  else
    return "Miss. "+name;
  
}

}


@Pipe({
  name:'EligibleforVoter'
})

export class CustomPipeComponent2 implements PipeTransform{
  transform(DOB:string):boolean{
    let newDate = new Date(DOB);
    let olddate = new Date('01/01/1900');
    if(newDate.getDay > olddate.getDay )
    return false;
    else
    return true;
  }
}