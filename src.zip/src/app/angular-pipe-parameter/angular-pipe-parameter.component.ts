import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-pipe-parameter',
  templateUrl: './angular-pipe-parameter.component.html',
  styleUrls: ['./angular-pipe-parameter.component.css']
})
export class AngularPipeParameterComponent {
today : number = Date.now();
salary : number = 45356.50;
}
 