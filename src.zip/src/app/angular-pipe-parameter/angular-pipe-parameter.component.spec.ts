import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularPipeParameterComponent } from './angular-pipe-parameter.component';

describe('AngularPipeParameterComponent', () => {
  let component: AngularPipeParameterComponent;
  let fixture: ComponentFixture<AngularPipeParameterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AngularPipeParameterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AngularPipeParameterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
