import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { STUDENTComponent } from './student/student.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentCountComponent } from './student-count/student-count.component';
import { IfStatementComponent } from './if-statement/if-statement.component';
import { NgSwitchDirectiveComponent } from './ng-switch-directive/ng-switch-directive.component';
import {AngularPipeComponent} from './angular-pipe/angular-pipe.component';
import { AngularPipeParameterComponent } from './angular-pipe-parameter/angular-pipe-parameter.component';
import { CustomPipeComponent,CustomPipeComponent2 } from './custom-pipe/custom-pipe.component';
import { StudentNewListComponent } from './student-new-list/student-new-list.component';
import { StudentNewListDetailsComponent } from './student-new-list-details/student-new-list-details.component';
import { AngularRoutingTestComponent } from './angular-routing-test/angular-routing-test.component';
import { LoginComponent } from './login/login.component';
import { CustomErrorComponent } from './custom-error/custom-error.component';
import { StudentUseServiceComponent } from './student-use-service/student-use-service.component';
import { BootstrapExampleComponent } from './bootstrap-example/bootstrap-example.component';


@NgModule({
  declarations: [
    AppComponent,
    STUDENTComponent,
    StudentListComponent,
    StudentCountComponent,
    IfStatementComponent,
    NgSwitchDirectiveComponent,
    AngularPipeComponent,
    AngularPipeParameterComponent,
    CustomPipeComponent,
    CustomPipeComponent2,
    StudentNewListComponent,
    StudentNewListDetailsComponent,
    AngularRoutingTestComponent,
    LoginComponent,
    CustomErrorComponent,
    StudentUseServiceComponent,
    BootstrapExampleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  // bootstrap: [AppComponent,StudentListComponent]
  // bootstrap: [STUDENTComponent]
  // bootstrap: [IfStatementComponent]
  // bootstrap: [NgSwitchDirectiveComponent]
    // bootstrap: [AngularPipeComponent]
    // bootstrap :[AngularPipeParameterComponent]
    // bootstrap: [AngularRoutingTestComponent]
    // bootstrap:[StudentUseServiceComponent]
    bootstrap:[StudentListComponent]
})
export class AppModule { }
