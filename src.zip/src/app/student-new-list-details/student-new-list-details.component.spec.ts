import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentNewListDetailsComponent } from './student-new-list-details.component';

describe('StudentNewListDetailsComponent', () => {
  let component: StudentNewListDetailsComponent;
  let fixture: ComponentFixture<StudentNewListDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentNewListDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentNewListDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
