import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-new-list-details',
  templateUrl: './student-new-list-details.component.html',
  styleUrls: ['./student-new-list-details.component.css']
})
export class StudentNewListDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
