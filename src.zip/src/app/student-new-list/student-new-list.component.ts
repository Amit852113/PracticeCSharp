import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-new-list',
  templateUrl: './student-new-list.component.html',
  styleUrls: ['./student-new-list.component.css']
})
export class StudentNewListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
