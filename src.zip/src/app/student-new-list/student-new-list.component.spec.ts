import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentNewListComponent } from './student-new-list.component';

describe('StudentNewListComponent', () => {
  let component: StudentNewListComponent;
  let fixture: ComponentFixture<StudentNewListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentNewListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentNewListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
