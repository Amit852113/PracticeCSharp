import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularRoutingTestComponent } from './angular-routing-test.component';

describe('AngularRoutingTestComponent', () => {
  let component: AngularRoutingTestComponent;
  let fixture: ComponentFixture<AngularRoutingTestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AngularRoutingTestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AngularRoutingTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
