import { Component, OnInit } from '@angular/core';
import{Router} from'@angular/router';

@Component({
  selector: 'app-angular-routing-test',
  templateUrl: './angular-routing-test.component.html',
  styleUrls: ['./angular-routing-test.component.css']
})
export class AngularRoutingTestComponent  {
constructor(private router:Router){}
  getStuedentNew()
  {
    this.router.navigate(['/StudentNewLink']);
  }

  getStudentNewDetails(){
    this.router.navigate(['/StudentNewLinkDetails']);
  }
  getLogin()
  {
    this.router.navigate(['/Login']);
  }

 

}
