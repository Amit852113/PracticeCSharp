import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  //  templateUrl: './app.component.html',
  //  styleUrls: ['./app.component.css']
   template: `<div>
                   /* <button [class]='ClassesToApply'>Click Me</button>
                 <br>
                   <button style='color:blue'>Click Me</button>
                   <br>
                   <button style='color:green' [style.font-size.px]="FontSize">Press Me</button>
                   <br>
                   <button style='color:pink' [style.fontWeight]="IsBold">CLick Me</button>
                   <br>
                 <button style='color:red' [ngStyle]="AddCSSStyle()">Press Me</button>
                   <br>
                   <p>Click Event </p>
                   <button (click)="onClick()">Click Me</button> */
                  <br>
                   Name : <input [value]='Name' (input)= 'Name = $event.target.value'>
                   <br>
                   You entered : {{Name}}

                   <br>
                   <h3> Two Binding through NgModule</h3>
                   Name : <input [(ngModel)] ='ApplyName'>
                   you entered : {{ApplyName}}
               </div>`
})
export class AppComponent {
  //  pageHeader: string = 'Student Details';
  //  FirstName: string = 'Anurag';
  //  LastName: string = 'Mohanty';
  //  Branch: string = 'CSE';
  //  Mobile: number = 9876543210;
  //  Gender: string = 'Male';
  //  Age: number = 22;

  //  showDetails: boolean = false;

  //  ToggleDetails() : void{
  //    this.showDetails = !this.showDetails;
  //  }

   Name : string ='Amit';
   ApplyName : string ='TestName';

   ClassesToApply : string = 'italicClass boldClass';
  IsBold: boolean = true;
   FontSize: number = 40;
   IsItalic: boolean = true;

   AddCSSStyle(){
     let CssStyles = {
      'font-weight' : this.IsBold? 'bold':'normal',
       'font-style' : this.IsItalic? 'italic':'normal',
       'font-size.px' : this.FontSize
     };
     return CssStyles;
  }

   onClick() : void {
     console.log('Button Clicked');
   }
}
