import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentUseServiceComponent } from './student-use-service.component';

describe('StudentUseServiceComponent', () => {
  let component: StudentUseServiceComponent;
  let fixture: ComponentFixture<StudentUseServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentUseServiceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentUseServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
