import { Component, OnInit } from '@angular/core';
import {StudentServiceService} from '../student-service.service';

@Component({
  selector: 'app-student-use-service',
  templateUrl: './student-use-service.component.html',
  styleUrls: ['./student-use-service.component.css'],
  providers: [StudentServiceService]
})
export class StudentUseServiceComponent  {
students : any[];
title : string;
private _studentService :StudentServiceService;

  // constructor(private _studentService: StudentServiceService) {
    constructor(studentService: StudentServiceService) {
    // this.students = this._studentService.getStudent();
    this._studentService = studentService;
   }

   ngOnInit(){
     this.students = this._studentService.getStudent();
     this.title = this._studentService.getsTitle();
   }



}
