﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{

    /* Point should be remember
     * Rule 1: If a method does not have body,then it should be declared as abstract using the abstract modifier else it leads to compile time error:
        “must declare a body because it is not marked abstract, extern, or partial”
             public class Example
                {
                        // compile time error: must declare a body because it is not marked abstract, extern, or partial
                        void m1(); 
                }
            =============================================================================================
      * Rule 2: If a class has an abstract method it should be declared as abstract by using the keyword abstract 
              else it leads to a compile-time error: ‘Example.m1()’ is abstract but it is contained in non-abstract class ‘Example‘.
                public class Example
                {
                        //'Example.m1()' is abstract but it is contained in non-abstract class 'Example' 
                        public abstract void m1();
                }
           ======The correct syntax is======
                public abstract class Example
                {
                        public abstract void m1();
                } 
           ===============================================================================================     
      * Rule 3: If a class is declared as abstract it cannot be instantiated violation leads to compile time Error.
                public abstract class Example
                {
                        public abstract void m1();
                        public static void Main(String[] args)
                        {
                                //Cannot create an instance of the abstract class or interface 'Example'
                                Example e = new Example();
                        }
                }
                ===========================================================================================
      * Rule 4: The sub-classes of an abstract class should override all the abstract methods or it should be declared as abstract else it leads to the compile-time error:
                public class Sample : Example
                {
                            public override void m1()
                            {
                                    Console.WriteLine("m1 method");
                            }
                            public override void m2()
                            {
                                    Console.WriteLine("m2 method");
                            }
                }
                =============================================================================================
                * We can interit same time interface as well abstract class from derived class
     */ 

    public abstract class Plan
    {
        protected double rate;
        public abstract void getRate();
        public void calculate(int unit)
        {
            Console.Write("Bill amount for " + unit + " Units is Rs. ");
            Console.WriteLine(rate * unit);           
        }
    }
    //public abstract class ABC : Plan
    //{
    //    public abstract override void getRate();
    //    public void show()
    //    {
    //        Console.WriteLine("Hi");
    //    }
    //}
    //public class xyz : ABC
    //{
    //    public override void getRate()
    //    {
    //        Console.WriteLine("HI");
    //    }
    //    public new void calculate(int a) // we can call super class calculate method with this class object ,But if required same method as parent class method in this class then use new keyword in this method.
    //    {
    //        Console.WriteLine("Value of A :" + a);
    //    }
    //    public new void show()
    //    {
    //        Console.WriteLine("Calling show method of ABC class through  XYZ class");
    //    }
    //}

    public interface InterfaceTest
    {
        void display();
    }

    public class CommercialPlan : Plan,InterfaceTest// Here same time we have inherit Interface as well as Abstract class also
    {
        public override void getRate()
        {
            rate = 5.0; 
        }

        void InterfaceTest.display()
        {
            Console.WriteLine("Interface Display method Calling");
        }
    }

    public class DomesticPlan : Plan
    {
        public override void getRate()
        {
            rate = 2.5;
        }
    }

    class Abstract_Class_Method_Demo
    {
        static void Main()
        {
            Plan p;
            Console.WriteLine("Commercial Plan");
            p = new CommercialPlan();
            p.getRate();
            p.calculate(200);

            //xyz abc = new xyz();
            //abc.calculate(10);
            //abc.show();
            //((InterfaceTest)p).display();
            //InterfaceTest obj = new CommercialPlan();
            //obj.display();


            Console.WriteLine("Domestic Plan");
            p = new DomesticPlan();
            p.getRate();
            p.calculate(200);


            Console.ReadLine();
        }
    }
}
