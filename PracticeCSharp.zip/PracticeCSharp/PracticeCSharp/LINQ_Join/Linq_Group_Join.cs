﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ_Join
{
    class Linq_Group_Join
    {
        public class Employee
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public int DepartmentId { get; set; }
            public static List<Employee> GetAllEmployees()
            {
                return new List<Employee>()
            {
                new Employee { ID = 1, Name = "Preety", DepartmentId = 10},
                new Employee { ID = 2, Name = "Priyanka", DepartmentId =20},
                new Employee { ID = 3, Name = "Anurag", DepartmentId = 30},
                new Employee { ID = 4, Name = "Pranaya", DepartmentId = 30},
                new Employee { ID = 5, Name = "Hina", DepartmentId = 20},
                new Employee { ID = 6, Name = "Sambit", DepartmentId = 10},
                new Employee { ID = 7, Name = "Happy", DepartmentId = 10},
                new Employee { ID = 8, Name = "Tarun", DepartmentId = 0},
                new Employee { ID = 9, Name = "Santosh", DepartmentId = 10},
                new Employee { ID = 10, Name = "Raja", DepartmentId = 20},
                new Employee { ID = 11, Name = "Ramesh", DepartmentId = 30}
            };
            }
        }

        public class Department
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public static List<Department> GetAllDepartments()
            {
                return new List<Department>()
                {
                    new Department { ID = 10, Name = "IT"},
                    new Department { ID = 20, Name = "HR"},
                    new Department { ID = 30, Name = "Sales"  },
                };
            }
        }
        static void Main()
        {
            //Method Syntax
            var groupJoinM = Department.GetAllDepartments().
                             GroupJoin(
                                Employee.GetAllEmployees(),
                                dept => dept.ID,
                                emp => emp.DepartmentId,
                                (dept, emp) => new { dept, emp }
                                );

            var groupJoinQ = (from dept in Department.GetAllDepartments()
                              join
                              emp in Employee.GetAllEmployees()
                              on 
                              dept.ID equals emp.DepartmentId
                              into joinGroup
                              select new { dept, joinGroup});

            foreach(var item in groupJoinQ)
            {
                Console.WriteLine(  "Department Name : " + item.dept.Name);
                foreach(var emp in item.joinGroup)
                {
                    Console.WriteLine($"Employee ID : " + emp.ID + " Empolyee Name : " + emp.Name);
                }
            }

            //For left join
            Console.WriteLine("==================Left Join============================");
            var ResultLeftJoin = from emp in Employee.GetAllEmployees()
                                 join
                                 dept in Department.GetAllDepartments()
                                 on
                                 emp.DepartmentId equals dept.ID
                                 into employeeleftjoin
                                 from department in employeeleftjoin.DefaultIfEmpty()
                                 select new { emp, department };


            foreach(var item in ResultLeftJoin)
            {
                Console.WriteLine($"Employee ID :" + item.emp.ID + " Employee Name :" + item.emp.Name + "Department :" + item.department?.Name);
            }

            Console.ReadLine();
        }
    }
}
