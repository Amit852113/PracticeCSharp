﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ_Join
{
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int AddressId { get; set; }
        public static List<Employee> GetAllEmployees()
        {
            return new List<Employee>()
            {
                new Employee { ID = 1, Name = "Preety", AddressId = 1 },
                new Employee { ID = 2, Name = "Priyanka", AddressId = 2 },
                new Employee { ID = 3, Name = "Anurag", AddressId = 3 },
                new Employee { ID = 4, Name = "Pranaya", AddressId = 4 },
                new Employee { ID = 5, Name = "Hina", AddressId = 5 },
                new Employee { ID = 6, Name = "Sambit", AddressId = 6 },
                new Employee { ID = 7, Name = "Happy", AddressId = 7},
                new Employee { ID = 8, Name = "Tarun", AddressId = 5 },
                new Employee { ID = 9, Name = "Santosh", AddressId = 4 },
                new Employee { ID = 10, Name = "Raja", AddressId = 10},
                new Employee { ID = 11, Name = "Sudhanshu", AddressId = 11}
            };
        }
    }
    public class Address
    {
        public int AddID { get; set; }
        public string AddressLine { get; set; }
        public static List<Address> GetAllAddresses()
        {
            return new List<Address>()
            {
                new Address { AddID = 1, AddressLine = "AddressLine1"},
                new Address { AddID = 2, AddressLine = "AddressLine2"},
                new Address { AddID = 3, AddressLine = "AddressLine3"},
                new Address { AddID = 4, AddressLine = "AddressLine4"},
                new Address { AddID = 5, AddressLine = "AddressLine5"},
                new Address { AddID = 9, AddressLine = "AddressLine9"},
                new Address { AddID = 10, AddressLine = "AddressLine10"},
                new Address { AddID = 11, AddressLine = "AddressLine11"},
            };
        }
    }
    class LINQ_Inner_Join
    {
         static void Main()
        {

            //Method Syntax
            var innerJoinMethodM = Employee.GetAllEmployees().   
                                   Join(Address.GetAllAddresses(), 
                                   employee => employee.AddressId, 
                                   address => address.AddID, 
                                   (employee, address) => new
                                   { EmployeeName = employee.Name,
                                       AddressLine = address.AddressLine
                                   }).ToList();

            //Method Syntax
            var innerJoinMethodQ = (from emp in Employee.GetAllEmployees()
                                    join
                                    address in Address.GetAllAddresses()
                                    on emp.AddressId equals address.AddID
                                    select new
                                    {
                                        EmployeeName = emp.Name,
                                        AddressLine = address.AddressLine
                                    }).ToList();

            foreach (var emp in innerJoinMethodQ)
            {
                Console.WriteLine($"Employee Name :" + emp.EmployeeName + " Address : " + emp.AddressLine);
            }
            Console.ReadLine();
        }
    }
}
