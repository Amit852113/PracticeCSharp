﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace PracticeCSharp.Collection
{
    class CollectionQueue
    {
        static void Main()
        {
            Queue q = new Queue();
            q.Enqueue(100);
            q.Enqueue("Amit");
            q.Enqueue(true);
            q.Enqueue(12.56f);
            q.Enqueue(150.00);

            foreach(object obj in q)
            {
                Console.Write(obj + "  ");
            }

            Console.WriteLine();
            Console.WriteLine($"Dequeue form Queue : {q.Dequeue()}");
            Console.WriteLine();
            foreach (object obj in q)
            {
                Console.Write(obj + "  ");
            }
            Console.WriteLine();
            Console.WriteLine($"Peek form Queue : {q.Peek()}");

            Console.WriteLine($"Is this value(amit) present in queue :{q.Contains("Amit")}");
            Console.ReadLine();
        }
    }
}
