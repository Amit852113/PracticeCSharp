﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace PracticeCSharp.Collection
{
    class CollectionArrayList
    {

        public static void Main()
        {
            ArrayList al = new ArrayList();
            Console.WriteLine("Initial Capacity: " + al.Capacity);
            al.Add(100);
            al.Add("Amit");
            al.Add(100.25f);
            Console.WriteLine("Capacity of Arraylist After Adding of 3 value : " + al.Capacity);
            al.Add(true);
            al.Add(100.00);
            Console.WriteLine("capacity of ArrayList after adding more 1 value : " + al.Capacity);
            foreach (object obj in al)
            {
                Console.WriteLine(obj + " ");
            }
            al.Remove(100);
            al.RemoveAt(2);

            foreach(object obj in al)
            {
                Console.WriteLine(obj + " ");
            }
            Console.ReadLine();
        }
    }
}
