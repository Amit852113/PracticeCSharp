﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace PracticeCSharp.Collection
{
    class CollectionStack
    {
        static void Main()
        {
            Stack s = new Stack();

            s.Push(100);
            s.Push("Amit");
            s.Push(true);
            s.Push(12.50f);
            s.Push(40.56);

            foreach(object obj in s)
            {
                Console.WriteLine(obj + " ");
            }

            Console.WriteLine("Element Pop from stack : " + s.Pop());
            Console.WriteLine();

            Console.WriteLine("Element Peek from stack : " + s.Peek());
            Console.WriteLine();
            Console.WriteLine($"Count of Stack is : {s.Count}");
            Console.ReadLine();
        }
    }
}
