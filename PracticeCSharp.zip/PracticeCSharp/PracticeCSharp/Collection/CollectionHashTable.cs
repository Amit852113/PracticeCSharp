﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace PracticeCSharp.Collection
{
    class CollectionHashTable
    {
        static void Main()
        {
            Hashtable ht = new Hashtable();

            ht.Add("EmpId", 1001);
            ht.Add("EmpName", "Amit");
            ht.Add("Department", "IT");
            ht.Add("Salary", 10000);
            ht.Add("IsActive", true);

            Console.WriteLine("Details of Employee");
            foreach(object obj in ht.Keys)
            {
                Console.WriteLine(obj + " : " + ht[obj]);
            }

            Console.WriteLine("Printing with Key");
            Console.WriteLine("Department : " + ht["Department"]);

            ht.Remove("IsActive");
            Console.WriteLine("=========================");
            foreach (object obj in ht.Keys)
            {
                Console.WriteLine(obj + " : " + ht[obj]);
            }

            Console.WriteLine("Capacity of Hashtable : " + ht.Count);

            Console.WriteLine("The HashTable Key is available : " + ht.ContainsKey("EmpName"));
            Console.WriteLine("The HashTable value is available : " + ht.ContainsValue(10000));
            Console.ReadLine();

        }
    }
}
