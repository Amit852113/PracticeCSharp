﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Delegate
{
    public delegate void RectangleMulriDelegagte(double width, double Height);
    class MultiDelegate
    {
       public void GetArea(double width,double Height)
        {
            Console.WriteLine("The area of Rectangle is : " + (width * Height));
        }
        public void GetPremeter(double width, double height)
        {
            Console.WriteLine("The Premeter of Rectangle is : " + (2 *(width * height)));
        }

        static void Main()
        {
            MultiDelegate md = new MultiDelegate();

            RectangleMulriDelegagte RMD = new RectangleMulriDelegagte(md.GetArea);

            RMD += md.GetPremeter;

            RMD(15, 20);

            Console.WriteLine("==================");

            RMD.Invoke(10, 10);
            Console.WriteLine("==================");

            RMD -= md.GetPremeter;

            RMD.Invoke(5, 5);

            Console.ReadLine();
        }
    }
}
