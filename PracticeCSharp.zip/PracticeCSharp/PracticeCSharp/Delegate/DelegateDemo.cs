﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Delegate
{
    public delegate void AddDel(int a, int b);
    public delegate string SayHelloDel(string name);
    class DelegateDemo
    {
        
        public void sum(int a , int b)
        {
            Console.WriteLine("The Sum of Two number is :" + (a + b));
        }
        public string Hello(string name)
        {
            return "Hello " + name;
        }

        static void Main()
        {
            DelegateDemo obj = new DelegateDemo();

            AddDel ad = new AddDel(obj.sum);        //Instantiating the delegate  
            SayHelloDel sd = new SayHelloDel(obj.Hello); //Instantiating the delegate 

            ad(30, 20);//Invoking Delegate
           // ad.Invoke(20, 20);//Invoking Delegate

            string stringResult = sd("Amit");//Invoking Delegate
            //sd.Invoke("shraddha");//Invoking Delegate

            Console.WriteLine(stringResult);
            Console.ReadLine();        
        }

    }
}
