﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Delegate
{
    public delegate string GreetingDelegate(string name);
    class AnonymousMethods
    {
        public static void Main()
        {
            // *****for testing purpose of interger literal*****
            //int x = 0x23fe;
            //int j = x + 1;
            //Console.WriteLine(x + " " + j);
            
            string Messsage = "Welcome to my Website";
            GreetingDelegate gd = delegate (string name)
            { 
                //return "Hello " + name + " Welcome to my Website";
                return "Hello " + name + " "+Messsage;
            };
            string GreetingString = gd("Amit");
            Console.WriteLine(GreetingString);
            Console.ReadLine();
        }
    }
}
