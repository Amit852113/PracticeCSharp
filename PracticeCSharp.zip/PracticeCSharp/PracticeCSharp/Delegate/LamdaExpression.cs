﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Delegate
{
    class LamdaExpression
    {
        public delegate string DelHello(string name);

        public static void Main()
        {
            DelHello dh = (name) =>
            {
                return "Hello " + name + " Welcome to my website";
            };
            //string result = dh("Amit");
            string result = dh.Invoke("Amit");
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
