﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Generic_Collection
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Salary { get; set; }
    }
    class GenericMethodList
    {
        static void Main()
        {

            

            Employee e1 = new Employee()
            {
                Id = 1,
                Name="Amit",
                Gender = "Male",
                Salary=5000                
            };
            Employee e2 = new Employee()
            {
                Id = 2,
                Name = "Sumit",
                Gender = "Male",
                Salary = 8000
            };
            Employee e3 = new Employee()
            {
                Id = 3,
                Name = "Shraddha",
                Gender = "Female",
                Salary = 15000
            };

            Employee e4 = new Employee()
            {
                Id = 3,
                Name = "Praveen",
                Gender = "Male",
                Salary = 10000
            };
            List<Employee> EmpList = new List<Employee>();
            EmpList.Add(e1);
            EmpList.Add(e2);
            EmpList.Add(e3);

            if (EmpList.Contains(e2))
            {
                Console.WriteLine("Employee2 object exists in the list");
            }
            else
            {
                Console.WriteLine("Employee2 object does not exists in the list");
            }


            if (EmpList.Exists(e => e.Name.StartsWith("A"))){
               Console.WriteLine("List contains Employees whose name starts with A");
            }
            else
            {
                Console.WriteLine("List does not contains Employees whose name starts with A");
            }
            Console.WriteLine("===========================");
            Console.WriteLine("Use Find() method");
            Employee emp = EmpList.Find(x => x.Gender == "Male");
            Console.WriteLine("ID ={0},Name={1},Gender ={2},Salary ={3}", emp.Id, emp.Name, emp.Gender, emp.Salary);

            Console.WriteLine("===========================");
            Console.WriteLine("Use FindLast() method");
            Employee emp2 = EmpList.FindLast(x => x.Gender == "Male");
            Console.WriteLine("ID ={0},Name={1},Gender ={2},Salary ={3}", emp2.Id, emp2.Name, emp2.Gender, emp2.Salary);

            List<Employee> filterEmployee = EmpList.FindAll(x => x.Gender == "Male");

            Console.WriteLine("===========================");
            Console.WriteLine("Use FindAll() method");
            foreach (Employee femp in filterEmployee)
            {
                Console.WriteLine("ID ={0},Name={1},Gender ={2},Salary ={3}", femp.Id, femp.Name, femp.Gender, emp2.Salary);
            }


            Console.ReadLine();


        }
    }
}
