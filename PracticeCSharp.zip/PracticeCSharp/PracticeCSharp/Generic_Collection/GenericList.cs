﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Generic_Collection
{
    class GenericList
    {
        static void Main()
        {
            List<int> Glist = new List<int>();
            Console.WriteLine("The capacity on starting time of List :" + Glist.Capacity);
            Glist.Add(100);
            Glist.Add(200);
            Glist.Add(300);
            Glist.Add(400);
            Glist.Add(350);

            Console.WriteLine($"Capacity After adding of 5 value in list :{Glist.Capacity} ");

            foreach (int item in Glist)
            {
                Console.WriteLine(item + " ");
            }

            Glist.Insert(2, 1000);
            Glist.Remove(400);
            Glist.Add(600);
            Glist.RemoveAt(4);

            Console.WriteLine();

            for (int i =0; i < Glist.Count; i++)
            {
                Console.WriteLine(Glist[i] + " ");
            }
            Console.ReadLine();

        }
    }
}
