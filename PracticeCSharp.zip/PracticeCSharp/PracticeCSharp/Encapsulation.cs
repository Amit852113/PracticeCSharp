﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{
    class Bank
    {
        private double _balace;
        public double Balance//hiding the code from out side the world
        {
            get
            {
                return _balace; 
            }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("Value cannot be Negative");
                }
                else
                {
                    _balace = value;
                }
            }
        }
    }
    class Encapsulation
    {
        static void Main()
        {
            Bank SBI = new Bank();
            SBI.Balance = 100;
            Console.WriteLine(SBI.Balance);
            SBI.Balance = -200;
            SBI.Balance = 200;
            Console.WriteLine(SBI.Balance);
            Console.ReadLine();

        }
       
    }
}
