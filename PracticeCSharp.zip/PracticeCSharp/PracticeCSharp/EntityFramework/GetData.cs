﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.EntityFramework
{
    class GetData
    {
        public static void Main()
        {
            using(EgragiousEntities DBEntities = new EgragiousEntities())
            {
                List<DepartmentsTest> listDepartment = DBEntities.DepartmentsTests.ToList();
                Console.WriteLine();
                foreach(DepartmentsTest dept in listDepartment)
                {
                    Console.WriteLine($"Department :{dept.Name} , Location : {dept.Location}");
                    foreach(EmployeesTest emp in dept.EmployeesTests)
                    {
                        Console.WriteLine($"\t Name : {emp.Name} ,  Email : {emp.Email}  , Gender : {emp.Gender} ,  Salary : {emp.Salary}");
                    }
                    Console.WriteLine();
                }
            }
            Console.ReadLine();
        }
    }
}
