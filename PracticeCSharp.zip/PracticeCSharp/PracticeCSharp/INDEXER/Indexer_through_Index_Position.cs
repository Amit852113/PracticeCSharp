﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.INDEXER
{
    public class Employee
    {
        //Declare the properties
        public int ID { get; set; }
        public string Name { get; set; }
        public string Job { get; set; }
        public double Salary { get; set; }
        public string Location { get; set; }
        public string Department { get; set; }
        public string Gender { get; set; }
        //Initialize the properties through constructor
        public Employee(int ID, string Name, string Job, int Salary, string Location,
                        string Department, string Gender)
        {
            this.ID = ID;
            this.Name = Name;
            this.Job = Job;
            this.Salary = Salary;
            this.Location = Location;
            this.Department = Department;
            this.Gender = Gender;
        }

        public object this [int index]
        {
            get
            {
                if (index == 0)
                    return ID;
                else if (index == 1)
                    return Name;
                else if (index == 2)
                    return Job;
                else if (index == 3)
                    return Salary;
                else if (index == 4)
                    return Location;
                else if (index == 5)
                    return Department;
                else if (index == 6)
                    return Gender;
                else
                    return null;
            }
            set
            {
                if (index == 0)
                    ID = Convert.ToInt32(value);
                else if (index == 1)
                    Name = value.ToString();
                else if (index == 2)
                    Job = value.ToString();
                else if (index == 3)
                    Salary = Convert.ToDouble(value);
                else if (index == 4)
                    Location = value.ToString();
                else if (index == 5)
                    Department = value.ToString();
                else if(index == 6)
                    Gender = value.ToString();                   
            }
        }
    }
     class Indexer_through_Index_Position
    {
         static void Main()
        {
            Employee emp = new Employee(101, "Pranaya", "SSE", 10000, "Mumbai", "IT", "Male");

            Console.WriteLine("ID : " + emp[0]);
            Console.WriteLine("Name : " + emp[1]);
            Console.WriteLine("JOB : " + emp[2]);
            Console.WriteLine("Salary : " + emp[3]);
            Console.WriteLine("Location : " + emp[4]);
            Console.WriteLine("Department : " + emp[5]);
            Console.WriteLine("Gender : " + emp[6]);

            emp[1] = "Amit";
            emp[3] = 40000;
            emp[4] = "Hyderabad";
            Console.WriteLine("======================================================================");

            Console.WriteLine("ID : " + emp[0]);
            Console.WriteLine("Name : " + emp[1]);
            Console.WriteLine("JOB : " + emp[2]);
            Console.WriteLine("Salary : " + emp[3]);
            Console.WriteLine("Location : " + emp[4]);
            Console.WriteLine("Department : " + emp[5]);
            Console.WriteLine("Gender : " + emp[6]);

            Console.ReadLine();
        }
    }
}
