﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.INDEXER
{
    public class Employee2
    {
        //Declare the properties
        public int ID { get; set; }
        public string Name { get; set; }
        public string Job { get; set; }
        public double Salary { get; set; }
        public string Location { get; set; }
        public string Department { get; set; }
        public string Gender { get; set; }
        //Initialize the properties through constructor
        public Employee2(int ID, string Name, string Job, int Salary, string Location,
                        string Department, string Gender)
        {
            this.ID = ID;
            this.Name = Name;
            this.Job = Job;
            this.Salary = Salary;
            this.Location = Location;
            this.Department = Department;
            this.Gender = Gender;
        }

        public object this[string Name]
        {
            get
            {
                if (Name.ToUpper() == "ID")
                    return ID;
                else if (Name.ToUpper() == "NAME")
                    return Name;
                else if (Name.ToUpper() == "JOB")
                    return Job;
                else if (Name.ToUpper() == "SALARY")
                    return Salary;
                else if (Name.ToUpper() == "LOCATION")
                    return Location;
                else if (Name.ToUpper() == "DEPARTMENT")
                    return Department;
                else if (Name.ToUpper() == "GENDER")
                    return Gender;
                else
                    return null;
            }
            set
            {
                if (Name.ToUpper() == "ID")
                    ID = Convert.ToInt32(value);
                else if (Name.ToUpper() == "NAME")
                    Name = value.ToString();
                else if (Name.ToUpper() == "JOB")
                    Job = value.ToString();
                else if (Name.ToUpper() == "SALARY")
                    Salary = Convert.ToDouble(value);
                else if (Name.ToUpper() == "LOCATION")
                    Location = value.ToString();
                else if (Name.ToUpper() == "DEPARTMENT")
                    Department = value.ToString();
                else if (Name.ToUpper() == "GENDER")
                    Gender = value.ToString();
            }
        }
        class Indexer_through_Name
        {
            static void Main()
            {
                Employee2 emp = new Employee2(101, "Pranaya", "SSE", 10000, "Mumbai", "IT", "Male");

                Console.WriteLine("ID : " + emp["ID"]);
                Console.WriteLine("Name : " + emp["Name"]);
                Console.WriteLine("JOB : " + emp["job"]);
                Console.WriteLine("Salary : " + emp["salary"]);
                Console.WriteLine("Location : " + emp["location"]);
                Console.WriteLine("Department : " + emp["department"]);
                Console.WriteLine("Gender : " + emp["gender"]);

                emp["Name"] = "Amit";
                emp["Salary"] = 40000;
                emp["location"] = "Hyderabad";
                Console.WriteLine("======================================================================");

                Console.WriteLine("ID : " + emp["ID"]);
                Console.WriteLine("Name : " + emp["Name"]);
                Console.WriteLine("JOB : " + emp["job"]);
                Console.WriteLine("Salary : " + emp["salary"]);
                Console.WriteLine("Location : " + emp["location"]);
                Console.WriteLine("Department : " + emp["department"]);
                Console.WriteLine("Gender : " + emp["gender"]);

                Console.ReadLine();
            }
        }
    }
}
