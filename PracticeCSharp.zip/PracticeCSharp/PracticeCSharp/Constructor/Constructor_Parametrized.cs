﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Constructor
{

    /* Should be remember
     * The developer given constructor with parameters is called as the parameterized constructor in C#
     * If you want to initialize the object dynamically with the user given values then you need to use the parameterized constructor.
     * The advantage is that you can initialize each object with different values.
     */
    class Employee
    {
        int eid;
        string ename;
        public Employee(int eid, string ename)
        {
            this.eid = eid;
            this.ename = ename;
        }
        public void Display()
        {
            Console.WriteLine("Employee Id :" + eid);
            Console.WriteLine("Employee Name :" + ename);

        }
    }
    class Constructor_Parametrized
    {
        static void Main()
        {
            Employee e1 = new Employee(101, "Amit");
            Employee e2 = new Employee(102, "Arjun");
            e1.Display();
            e2.Display();
            Console.ReadKey();
        }
    }
}
