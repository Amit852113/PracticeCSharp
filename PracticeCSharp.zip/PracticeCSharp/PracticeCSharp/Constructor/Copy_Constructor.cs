﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Constructor
{
    /*Point should be remembe
     * The constructor which takes a parameter of the class type is called a copy constructor.
     * 
     */

    class Employee_Copy
    {
        int eid;
        string ename;

        public Employee_Copy()
        {
            Console.WriteLine("Enter Employee ID");
            this.eid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            this.ename = Console.ReadLine();
        }
        public Employee_Copy(Employee_Copy empCopy)//Copy constuctor
        {
            this.eid = empCopy.eid;
            this.ename = empCopy.ename;
        }
        public void Display()
        {
            Console.WriteLine("Employee ID is:" + this.eid);
            Console.WriteLine("Employee Name is:" + this.ename);
        }
    }
    class Copy_Constructor    {        
        static void Main()
        {
            Employee_Copy e1 = new Employee_Copy();
            Employee_Copy e2 = new Employee_Copy(e1);//Copy Consturctor
            e1.Display();
            e2.Display();
            Console.ReadKey();
        }
    }
}
