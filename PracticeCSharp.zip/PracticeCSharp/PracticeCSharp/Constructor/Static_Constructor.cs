﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Constructor
{
    /* Point should be rememebr
     * There can be only one static constructor in a class.
     * The static constructor should be without any parameter.
     * It can only access the static members of the class.
     * There should not be any access modifier in static constructor definition.
     * If a class is static then we cannot create the object for the static class.
     * Static constructor will be invoked only once i.e. at the time of first object creation of the class, from 2nd object creation onwards static constructor will not be called.
     */
    class Example
    {
        int i;
        static int j;

        public Example()
        {
            i = 100;
        }
        static Example()
        {
            j = 100;
        }

        public void Display()
        {
            Console.WriteLine("Value of I :" + i);
            i++;
            Console.WriteLine("Value of J :" + j);
            j++;
        }
    }
    class Static_Constructor
        {
            static void Main()
            {
                Example E1 = new Example();
                E1.Display();
                E1.Display();
                Example E2 = new Example();
                E2.Display();
                E2.Display();
                Console.ReadLine();
            }
        }
   
}
