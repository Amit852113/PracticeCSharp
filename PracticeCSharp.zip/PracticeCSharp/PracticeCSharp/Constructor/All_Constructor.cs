﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Constructor
{
    class Class_A
    {
        public Class_A()
        {
            Console.WriteLine("Default constructor of Class A");
        }
        static Class_A()
        {
            Console.WriteLine("Static constructor of Class A");
        }
        private Class_A(int a)
        {
            Console.WriteLine("Private constructor of Class A" + a);
        }
        public Class_A(string name)
        {
            Console.WriteLine("Parametrised constructor of Class A" + name);
        }
        public Class_A(Class_A abc)
        {
            Console.WriteLine("Copy constructor of Class A");
        }
    }
    class All_Constructor : Class_A
    {
        public All_Constructor()
        {
            Console.WriteLine("Default constructor of Class B");
        }
        static All_Constructor()
        {
            Console.WriteLine("Static constructor of Class B");
        }
        private All_Constructor(int a)
        {
            Console.WriteLine("Private constructor of Class B" + a);
        }
        public All_Constructor(string name)
        {
            Console.WriteLine("Parametrised constructor of Class B" + name);
        }
        public All_Constructor(All_Constructor abc)
        {
            Console.WriteLine("Copy constructor of Class B");
        }
        static void Main()
        {
            //    Class_A A = new Class_A("Amit");
            //    Class_A AA = new Class_A(A);
            //All_Constructor obj = new All_Constructor();
            All_Constructor B = new All_Constructor("Amit");
            All_Constructor BB = new All_Constructor(B);
            //All_Constructor BBB = new All_Constructor(10);
            //All_Constructor bbbb = new All_Constructor();
            Console.ReadLine();
        }
    }
}
