﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{

    /*Point Should be remember
     * A sealed class is completely opposite to an abstract class.
     * This sealed class cannot contain abstract methods.
     * It should be the bottom most class within the inheritance hierarchy.
     * A sealed class can never be used as a base class.
     * This sealed class is specially used to avoid further inheritance.
     * The keyword sealed can be used with classes, instance methods, and properties.
     */

    public class class1
    {
        public virtual void show() { }
    }
    public class Simple : class1
    {
        public sealed override void show()
        {
            Console.WriteLine("Sealed Method under Simple Class");
        }
        //public sealed void Test()
        //{
        //    //We can't create directly sealed method , we can only make sealed method that method virtual in super class
        //}
    }
    public class Complex : Simple
    {
        public new void show()
        {
            base.show();
            Console.WriteLine("Overridden Method under Complex Class");
        }
    }

    public class SealedDemo
    {
        static void Main()
        {
            Complex obj = new Complex();
            obj.show();

            Console.ReadLine();
        }
    }
}
