﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{
    /*Point Should be Remember
     * Extension methods must be defined only under the static class.
     * As an extension method is defined under a static class, compulsory that method should be defined as static whereas once the method is bound with another class, 
            the method changes into non-static.
     * The first parameter of an extension method is known as the binding parameter
            which should be the name of the class to which the method has to be bound and the binding parameter should be prefixed with "this" keyword.
     * An extension method can have only one binding parameter and that should be defined in the first place of the parameter list.
     * If required, an extension method can be defined with normal parameter also starting from the second place of the parameter list.

     */
    public static class CreateExtensionMethod
    {
         public static int GetLength(this string inputstring)
        {
            if (!string.IsNullOrEmpty(inputstring))
            {
                string[] StrArray = inputstring.Split(' ');
                return StrArray.Count();
            }
            else
            {
                return 0;
            }
        }
    }
    class ExtensionMethodsDemo
    {
        public static void Main()
        {
            string StringWord = "Amit Kumar";
            //int WordCount = CreateExtensionMethod.GetLength(StringWord);//through class name i.e static class
            int WordCount = StringWord.GetLength();
            Console.WriteLine(StringWord);
            Console.WriteLine("The Length of StringWord is :" + WordCount);
            Console.ReadLine();
        }
        
    }
}
