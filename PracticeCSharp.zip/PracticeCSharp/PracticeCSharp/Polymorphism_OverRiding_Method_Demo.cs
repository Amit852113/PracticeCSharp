﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{
    /* Point should be Remember
     * It is an approach of defining multiple methods with the same name and with the same signature.
     * Overriding of methods is not possible within the same class it must be performed under the child classes.
     * To override a parent class method under the child class, first, the child class require explicit permission from its parent.
     * This is all about changing the behavior of a method.
     * Used to implement dynamic polymorphism.
     * This is code replacement technique.
     * Use virtual keyword for base class function and override keyword in derived class function to implement function overriding.
     */
    public class SuperClass
    {
        public virtual void getDetails()
        {
            Console.WriteLine("Calling Super Class method");
        }
    }

    public class SubClass : SuperClass
    {
        public override void getDetails()
        {
            base.getDetails();            
            Console.WriteLine("Calling Sub class method");
        }
    }
    class Polymorphism_OverRiding_Method_Demo
    {
        static void Main()
        {
            SubClass SubClassObj = new SubClass();
            SubClassObj.getDetails();
            Console.ReadLine();
        }
    }
}
