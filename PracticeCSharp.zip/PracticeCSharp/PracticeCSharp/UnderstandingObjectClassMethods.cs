﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{
    class UnderstandingObjectClassMethods
    {
        public class Employee
        {
            public string FirstName;
            public string LastName;
            public override string ToString()
            {
                //int a = 10, b = 15;//local fuction
                //int sum = Sum(a, b);
                //int Sum(int x, int y)
                //{
                //    return (x + y);
                //}
                return FirstName + ", " + LastName;
            }
        }
        public static void Main()
        {
     
            Employee emp = new Employee();
            emp.FirstName = "Pranaya";
            emp.LastName = "Rout";
            Console.WriteLine(emp.ToString());

            //int a = 10, b = 15;//local fuction
            //int sum = Sum(a, b);
            //int Sum(int x, int y)
            //{
            //    return (x + y);
            //}

            Console.ReadKey();

        }
    }
}
