﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ
{
    class LINQ_OrderBy_Method
    {
        static void Main()
        {
            List<int> intList = new List<int>() { 10, 45, 35, 29, 100, 69, 58, 50 };
            List<string> stringList = new List<string>() { "Preety", "Tiwary", "Agrawal", "Priyanka", "Dewangan",
            "Hina","Kumar","Manoj", "Rout", "James"};
            Console.WriteLine("Before Sorting : ");

            foreach(int num in intList)
            {
                Console.Write(num + " ");
            }

            //Using Method Syntax
            var intOrderByM = intList.OrderBy(num => num).ToList();

            //Using Query Syntax
            var intOrderByQ = (from num in intList
                               orderby num
                               select num
                               ).ToList();
            Console.WriteLine();
            Console.WriteLine("After Sorting : ");
            foreach(int num in intOrderByQ)
            {
                Console.Write(num + " ");
            }

           
            //Using Method Syntax
            var MS = stringList.OrderBy(name => name);
            //Using Query Syntax
            var QS = (from name in stringList
                      orderby name ascending
                      select name).ToList();
            foreach (var item in MS)
            {
                Console.WriteLine(item + " ");
            }

            Console.WriteLine("==============Order By Descending");
            var intOrderByDescM = intList.OrderByDescending(num => num);
            var intOrderByDescQ = (from num in intList
                                  orderby num descending
                                   select num);
            foreach(int num in intOrderByDescQ)
            {
                Console.Write(num + " ");
            }


            Console.ReadLine();
        }
    }
}
