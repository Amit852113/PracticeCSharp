﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ
{
    class LINQ_Distinct_Method
    {
        public static void Main()
        {
            List<int> intList = new List<int> { 1, 2, 3, 5, 0, 3, 5, 6, 3, 7 };

            //using method syntax
            var Mvar = intList.Distinct();

            //using query syntax
            var Qvar = (from num in intList select num).Distinct().ToList();

            foreach(int num in Mvar)
            {
                Console.WriteLine(num + " ");
            }
            Console.WriteLine("==================================");


            //below code taking differentiate on capital and small alphabate
            string[] namesArray = { "Priyanka", "HINA", "hina", "Anurag", "Anurag", "ABC", "abc" };
            var distinctNames = namesArray.Distinct();
            foreach (var name in distinctNames)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("==================================");
            //below code doesn't differentiate on capital and small alphabate
            var UniqueNames = namesArray.Distinct(StringComparer.OrdinalIgnoreCase);
            foreach (var name in UniqueNames)
            {
                Console.WriteLine(name);
            }


            Console.ReadLine();
        }
    }

}
