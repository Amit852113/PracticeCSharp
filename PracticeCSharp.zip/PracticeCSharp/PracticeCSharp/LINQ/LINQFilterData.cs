﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ
{
    class LINQFilterData
    {
        static void Main(string[] args)
        {
            List<int> intList = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            IEnumerable<int> FilteredData = intList.Where(num => checkNum(num));

            foreach(int number in FilteredData)
            {
                Console.WriteLine(number + " ");
            }
            Console.ReadLine();
        }

        public static Boolean checkNum(int num)
        {
            if(num > 5)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
