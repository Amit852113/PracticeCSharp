﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ
{
    class LINQ_Intersect_Method
    {
        public static void Main()
        {
            List<int> intList1 = new List<int> { 1, 2, 3, 7, 4, 8 };
            List<int> intList2 = new List<int> { 2,5,7,3,8,1,9 };


            string[] dataSource1 = { "India", "USA", "UK", "Canada", "Srilanka" };
            string[] dataSource2 = { "India", "uk", "Canada", "France", "Japan" };

            //Method Syntax
            var intersectlistM = intList1.Intersect(intList2).ToList();

            //Query Syntax

            var intersectlistQ = (from inter in intList1 select inter).Intersect(intList2).ToList();

            foreach(int num in intersectlistM)
            {
                Console.WriteLine(num + " ");
            }


            Console.WriteLine("=======================================");

            //Method Syntax
            var stringInterM = dataSource1.Intersect(dataSource2).ToList();

            //Query Syntax
            var stringInterQ = (from interstring in dataSource1 select interstring).Intersect(dataSource2).ToList();
            foreach (var str in stringInterQ)
            {
                Console.WriteLine(str + " ");
            }

            Console.WriteLine("=============StringComparer OrdinalIgnoreCase==========================");

            //Method Syntax
            var stringComInterM = dataSource1.Intersect(dataSource2,StringComparer.OrdinalIgnoreCase).ToList();

            //Query Syntax
            var stringComInterQ = (from interstring in dataSource1 select interstring).Intersect(dataSource2,StringComparer.OrdinalIgnoreCase).ToList();
            foreach (var str in stringComInterQ)
            {
                Console.WriteLine(str + " ");
            }

            Console.ReadLine();
        }
    }
}
