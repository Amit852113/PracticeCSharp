﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ
{
    class LINQofType_Operator
    {
        static void Main(string[] args)
        {
            List<object> dataSource = new List<object>()
            {
                "Tom", "Mary", 50, "Prince", "Jack", 10, 20, 30, 40, "James"
            };

            //OfType Operator Using Method syntax
            List<int> intData = dataSource.OfType<int>().ToList();

            Console.WriteLine("OfType Operator Using Method syntax");
            foreach (int number in intData)
            {
                Console.Write(number + " ");
            }


            ///OfType Operator Using Query Syntax
            var stringData = (from name in dataSource
                              where name is string
                              select name).ToList();
            Console.WriteLine();
            Console.WriteLine("OfType Operator Using Query Syntax");
            foreach (string str in stringData)
            {
                Console.Write(str + " ");
            }

            //Using Method Syntax with condition
            
            List<int> intDataCon = dataSource.OfType<int>().Where(num => num > 20).ToList();
            Console.WriteLine();
            Console.WriteLine("Using Method Syntax with condition");
            foreach (int number in intDataCon)
            {
                Console.Write(number + " ");
            }

            //Using Qyery Syntax with Condition
            
            var stringDataCon = (from name in dataSource
                                          where name is string && name.ToString().Length > 3
                                          select name).ToList();

            Console.WriteLine();
            Console.WriteLine("Using Qyery Syntax with Condition");
            foreach (string str in stringDataCon)
            {
                Console.Write(str + " ");
            }


            Console.ReadKey();
        }
    }
}
