﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ
{
    class LINQ_First_and_FirstOrDefault_Methods
    {
        static void Main()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            int intFirst = numbers.First();
            Console.WriteLine("First method should be given at postion of 1st in datasource :" + intFirst);

            int intFirstmodules = numbers.First(num => num % 2 == 0);
            Console.WriteLine("First value of above from datasource is 2 because it divided by 2 :" + intFirstmodules);

            //int intFirst2 = numbers.First(num => num > 20);//it produces exception due to there are no any value greater than 20 on above dataSource

            int intFirst3 = numbers.FirstOrDefault(num => num > 50);//it will produce result as per the element datatype ex- int => 0,not raise exception here
            Console.WriteLine("This FirstOrDefault produce 0 by default as per the data type : " + intFirst3);

            Console.ReadLine();
        }
    }
}
