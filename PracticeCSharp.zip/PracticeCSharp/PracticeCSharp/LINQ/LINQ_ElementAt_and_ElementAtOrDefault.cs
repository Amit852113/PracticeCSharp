﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.LINQ
{
    class LINQ_ElementAt_and_ElementAtOrDefault
    {
        static void Main()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            //Method Syntax
            int intElement = numbers.ElementAt(1);
            Console.WriteLine(intElement);//should be second position value due indexed start from 0

            //int intElement2 = numbers.ElementAt(10);//exception got  system.ArgumentOfOutrRangeException

            //if we apply the ElementAt operator on an empty data source
            List<int> numbers2 = new List<int>() { };
            // int intElemnentAt = numbers2.ElementAt(1);//should be second position value due indexed start from 0
            int intElemnentAt = numbers2.ElementAtOrDefault(1);
            Console.WriteLine("Element Not available but default value should given " +intElemnentAt);

            Console.ReadLine();
        }
    }
}
