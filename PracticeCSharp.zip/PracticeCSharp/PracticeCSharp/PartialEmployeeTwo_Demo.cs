﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{
    /*Point to be Remember
     * we can physically split the content of the class into different files but even physically they are divided but logically it is one single unit only.
     * A class which code can be written in two or more files is known as partial class. To make any class as partial we need to use the keyword partial.
     * When working on large projects, splitting a class over separate files allows multiple programmers to work on it simultaneously.
     * All the parts spread across different class files, must use the partial keyword. Otherwise, a compiler error is raised.
                "Missing partial modifier.Another partial declaration of this type exists".
     * All the parts spread across different files, must have the same access modifiers. Otherwise, a compiler error is raised. 
                "Partial declarations have conflicting accessibility modifiers."
     * If any of the parts are declared as abstract, then the entire type is considered as abstract 
                        OR
       if any of the parts are declared as sealed, then the entire type is considered as sealed
                        OR
       if any of the parts inherit a class, then the entire type inherits that class.     
     */
    public partial class PartialEmployee
    {
        public void DisplayFullName()
        {
            Console.WriteLine(@"Full Name is :{0}{1}", _firstName, _lastName);
        }

        public void DisplayEmployeeDetails()
        {
            Console.WriteLine("Employee Details : ");
            Console.WriteLine(@"First Name :{0}", _firstName);
            Console.WriteLine(@"LastName :{0}", _lastName);
            Console.WriteLine(@"Gender :{0}", _gender);
            Console.WriteLine("Salary :{0}", _salary);
        }
    }
    class PartialEmployeeTwo_Demo
    {
        static void Main(string[] args)
        {
            PartialEmployee emp = new PartialEmployee();
            emp.FirstName = "Amit";
            emp.LastName = "Kumar";
            emp.Salary = 100000;
            emp.Gender = "Male";
            emp.DisplayFullName();
            emp.DisplayEmployeeDetails();
            Console.WriteLine("Press any key to exist.");
            Console.ReadKey();
        }
    }
}
