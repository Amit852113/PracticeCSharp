﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Technical_Logical
{
    class ReverseEachWordFromSentence
    {
        static void Main()
        {
            //string input = "DS tech blog";

            //string result = string.Join(" ", input

            //.Split(' ')

            //.Select(x => new String(x.Reverse().ToArray())));

            //Console.WriteLine(result);


            string str = "I am going to reverse myself.";
            string strrev = "";

            foreach (var word in str.Split(' '))
            {
                string temp = "";
                foreach (var ch in word.ToCharArray())
                {
                    temp = ch + temp;
                }
                strrev = strrev + temp + " ";
            }
            Console.WriteLine(strrev);  //I ma gniog ot esrever .flesym
            Console.ReadLine();

        }
    }
}
