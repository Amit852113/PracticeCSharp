﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Technical_Logical
{
    class Armstrong
    {
        public static void Main()
        {
            Console.WriteLine("please enter number : ");
            int num = int.Parse(Console.ReadLine());
            int num1 = num;
            int arm = 0;
            int mod = 0; 
            //153
            for(;num > 0;)
            {
                mod = num % 10;
                arm = arm + (mod * mod * mod);
                num = num / 10;
            }
            if(num1 == arm)
            {
                Console.WriteLine(num1 + " is armstrong number");
            }
            else
            {
                Console.WriteLine(num1 + " is not armstrong number");
            }
            Console.ReadLine();


        }
    }
}
