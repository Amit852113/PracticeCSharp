﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Technical_Logical
{
    class Pallingdrome
    {
        public static void Main()
        {
            //1221
            Console.Write("please enter number :");
            int num = int.Parse(Console.ReadLine());
            int num1 = num;
            int pall = 0;
            for(; num > 0;)
            {
                int mod = num % 10;
                pall = (pall * 10) + mod;
                num = num / 10;
            }
            if (num1 == pall)
            {
                Console.WriteLine(num1 + " is pallingdrome number");
            }
            else
            {
                Console.WriteLine(num1 + " is not pallingdrome number");
            }
            Console.ReadLine();
        }
    }
}
