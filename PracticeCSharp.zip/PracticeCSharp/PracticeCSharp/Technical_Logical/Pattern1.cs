﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Technical_Logical
{
       //-----*
       //----**
       //---***
       //--****
       //-*****

    class Pattern1
    {
        static void Main()
        {
            for(int i = 0; i < 6; i++)
            {
                for(int j = 0; j < (6 - i); j++)
                {
                    Console.Write(" ");
                }
                for(int k = 0; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
