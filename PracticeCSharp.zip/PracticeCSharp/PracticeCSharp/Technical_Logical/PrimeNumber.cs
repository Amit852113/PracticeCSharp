﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Technical_Logical
{
    class PrimeNumber
    {
        public static void Main()
        {
            //find out first 10 prime number
            int countprime = 0;
            for(int num = 3; countprime < 10;num++)
            {
                int count = 0;
                for (int i=1;i<num;i++)
                {
                    if (num % i == 0)
                    {
                        count++;
                    }
                }
                if(count <= 1)
                {
                    countprime++;
                    Console.WriteLine(num + " ");
                }
            }
                
            Console.ReadLine();

        }
    }
}
