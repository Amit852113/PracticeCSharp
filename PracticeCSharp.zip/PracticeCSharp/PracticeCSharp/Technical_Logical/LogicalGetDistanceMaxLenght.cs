﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Technical_Logical
{
    class LogicalGetDistanceMaxLenght
    {
        public static void Main()
        {
            string str = "11010000010000001";
            int lengthmin = 0, lengthmax = 0;
            for (int i = 0; i < str.Length; i++)
            {
                lengthmin = 0;
                if (str[i] == '1')
                {
                    for (int j = i+1; j < str.Length; j++)
                    {
                        if (str[i] != str[j])
                        {
                            lengthmin += 1;
                            
                        }
                        if(str[i] =='1' && str[j] == '1')
                        {
                            if (lengthmin > lengthmax)
                                lengthmax = lengthmin;
                            break;
                        }
                        
                    }
                }
            }
            Console.WriteLine(lengthmax);
            Console.ReadLine();
        }
    }
}
