﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{
    /* Point should be Remember
     * It is an approach of defining multiple methods with the same name but with a different signature.
     * Overloading a method can be performed within a class or within the child classes also.
     * To overload a parent class method under the child class, the child class does not require permission from the parent.
     * This is all about defining multiple behaviors to a method.
     * Used to implement static polymorphism.
     * This is code refinement technique.
     * No separate keywords are used to implement function overloading.
     */

    public class ADD1
    {
        public void add(int a, int b)
        {
            Console.WriteLine("Addition of two integer value is :" + (a + b));
        }
        public void add(float a ,float b)
        {
            Console.WriteLine("Addition of two float value is :" + (a + b));
        }
    }

    public class ADD2 : ADD1
    {
        public void add(string a , string b)
        {
            Console.WriteLine("Additon of two string value is :" + (a + b));
        }
    }

    class Polymorphism_Method_Overloading_Demo
    {
        static void Main()
        {
            ADD2 obj = new ADD2();
            obj.add(10, 20);
            obj.add(5.5f, 4.5f);
            obj.add("Amit ", "Kumar");
            Console.ReadLine();
        }
        
    }
}
