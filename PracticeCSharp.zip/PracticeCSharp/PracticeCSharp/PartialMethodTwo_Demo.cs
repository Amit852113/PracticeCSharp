﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{

    /*Point to be Remember
     * A partial class or a struct can contain partial methods. A partial method is created using the same partial keyword.
     * Partial methods are private by default and it is a compile-time error to include any access modifiers, including private. 
            The following code will raise an error stating –
                "A partial method cannot have access modifiers or the virtual, abstract, override, new, sealed, or extern modifiers".
                partial class PartialClass
                { 
                     private partial void PartialMethod();
                }
      * It is a compile-time error to include declaration and implementation at the same time for a partial method. 
                The code below produces a compile-time error – 
                        "No defining declaration found for implementing declaration of partial method ‘PartialDemo.PartialClass.partialMethod()’"
                partial class PartialClass
                {
                        partial void PartialMethod()
                        {
                                Console.WriteLine("PartialMethod Implemented");
                        }
                }
       * A partial method return type must be void. Including any other return type is a compile-time error – 
                    "Partial methods must have a void return type "
        * A partial method must be declared within a partial class or partial struct. A non-partial class or struct cannot include partial methods.
        * Signature of the partial method declaration must match with the signature of the implementation.
        * A partial method can be implemented only once. Trying to implement a partial method more than once raises a compile-time error –
                "A partial method may not have multiple implementing declarations. "
     */
    partial class PartialClass
    {
        partial void PartialMethod()
        {
            Console.WriteLine("Partial Partial Method Invoke");
        }
    }
    class PartialMethodTwo_Demo
    {
        static void Main()
        {
            PartialClass obj = new PartialClass();
            obj.PublicMethod();
            Console.ReadKey();
        }
        
    }
}
