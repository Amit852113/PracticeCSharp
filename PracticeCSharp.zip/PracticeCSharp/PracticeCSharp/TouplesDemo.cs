﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace PracticeCSharp
{
    class TouplesDemo
    {
        static void Main()
        {
            var values = new List<double>() { 10, 20, 30, 40, 50 };
            //var result = calculate(values);
            var (countResult, SumResult) = calculate(values);//Provide Explicitly names while storing the Result
            //Console.WriteLine($"There are {result.Item1} values and their sum is {result.Item2}");  1st way to get value thought item1 and item 2
            //Console.WriteLine($"There are {result.count} values and their sum is {result.sum}");//Tuples in C# with named Parameters
            Console.WriteLine($"There are {countResult} values and their sum is {SumResult}");
            Console.ReadKey();
        }
        //private static (int ,double) calculate(IEnumerable<double> values)  1st way to declare return data type not name of variable
        private static (int count, double sum) calculate(List<double> values)//Tuples in C# with named Parameters
        {
            int count = 0;
            double sum = 0.0;
            foreach(var value in values)
            {
                count++;
                sum += value;               
            }
            return (count,sum);
        }
    }
}
