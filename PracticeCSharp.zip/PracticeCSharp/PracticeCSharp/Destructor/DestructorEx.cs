﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp.Destructor
{
    class DestructorExample
    {
        public DestructorExample()
        {
            Console.WriteLine("Constructor is called");
        }
        ~DestructorExample()
        {
            Console.WriteLine("Destructor is called");
        }
    }

    class DestructorEx
    {
        static void Main()
        {
            DestructorExample de1 = new DestructorExample();
            DestructorExample de2 = new DestructorExample();
            DestructorExample de3 = new DestructorExample();
            de1 = null;
            de2 = null;
            de3 = null;
            GC.Collect();
            Console.ReadKey();
        }
    }
}
