﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{

    /* Point to be remember
     * We create an interface using interface keyword. Just like classes, the interface also contains properties, methods, delegates or events, but only declarations and no implementation.
                interface ICustomer
                {
                        void Print();
                }
     * It is a compile-time error to provide the implementation for any interface members.
                interface ICustomer
                {
                        void Print(){}   //Compile time error
                }
     * Interface members are public by default and they don’t allow explicit access modifiers
                interface ICustomer
                {
                        public void Print(); //Compile time error
                }
     * Interface cannot contain fields
                interface ICustomer
                {
                        int ID; //Compile time error
                        void Print();
                }
     * when a class or a struct inherits from an interface then it’s the responsibility of the class or struct to provide the implementation for all interface members otherwise we get a compile-time error
                interface ICustomer
                {
                         void Print();
                }
                class Customer : ICustomer //Compile time error
                {
                }
     */

    public interface ExInterface1
    {
        void Test();

        void Show();

        void display();
    }
    public interface ExInterface2
    {
        void Test();
        void Show();
        void display();

    }

    class ImplementInterafce : ExInterface1, ExInterface2 
    {
        //public modifier is not allowed once implement of explicitly interface
        void ExInterface1.Show()
        {
            Console.WriteLine("Calling ExInterface1 Show Method");
        }
        void ExInterface1.Test()
        {
            Console.WriteLine("Calling ExInterface1 Test Method");
        }


        public void display()//if method implementation is same in both the interface then there is no required interface name along with method name.
        {
            Console.WriteLine("calling ExInterface1 Display method");
        }

        void ExInterface2.Test()
        {
            Console.WriteLine("Calling ExInterface2 Test Method");
        }
        void ExInterface2.Show()
        {
            Console.WriteLine("Calling ExInterface2 Show Method");
        }

    }
    class Implement_Interafce_For_Multiple_Inheritance
    {
        static void Main()
        {
            ImplementInterafce obj = new ImplementInterafce();
            //obj.Test();  //not possible
            //obj.Show();  //not possible

            ((ExInterface1)obj).Show();
            ((ExInterface2)obj).Show();

            ExInterface1 EXI1 = new ImplementInterafce();
            EXI1.Show();
            EXI1.Test();
            EXI1.display();

            ExInterface2 EXI2 = new ImplementInterafce();
            EXI2.Test();
            EXI2.Show();
            EXI2.display();
            

            Console.ReadLine();
        }
    }
}
