﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{
    /* Point Should be remember
     * Method hiding also parent class methods can be redefined under child classes even if they were not declared as Virtual by using ‘new‘ keyword.
     * 
     */
    public class Super
    {
        public void Display()
        {
            Console.WriteLine("This is super class Display method");
        }
    }
    
    public class Sub : Super
    {
        int count = 0;
        public new void Display()
        {
            
            if (count < 5) { 
            Console.WriteLine("This is Sub class Display method");
                count++;
                this.Display();
            }
        }
    }
    class Polymorphism_Method_Hiding_Demo
    {

        static void Main()
        {
            Sub obj = new Sub();
            obj.Display();
            Console.ReadKey();
           
        }
    }
}
