﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeCSharp
{
    class check_RefKeyword_value
    {
        static void Main()
        {
            int x = 5;
            List<string> y = new List<string>();
            y.Add("xyz1");
            y.Add("xyz2");
            check_RefKeyword_value obj = new check_RefKeyword_value();
            obj.setEmp(ref x, ref y);
            //obj.setEmp(x,y);
            obj.display(x, y);
            Console.ReadLine();

            
        }
        public void setEmp(ref int x, ref List<string> y)
        {
            x = 10;
            y = new List<string>();
            y.Add("abc1");
            y.Add("abc2");
            //Console.WriteLine("x :" + x);

            //foreach (string i in y)
            //{
            //    Console.WriteLine(i);
            //}
        }

        public void display(int x, List<string> y)
        {

            Console.WriteLine("x :" + x);

            foreach (string i in y)
            {
                Console.WriteLine(i);
            }
        }
    }
}
