export class Employee {
    EmpId: number;  
    EmpName: string;  
    DateOfBirth: Date;  
    EmailId: string;  
    Gender: string;  
    Address: string;  
    PinCode: string;
}
