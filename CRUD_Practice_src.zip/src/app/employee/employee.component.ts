import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';  
import { Observable } from 'rxjs';  
import { EmployeeService } from '../employee.service';  
import { Employee } from '../employee'; 

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  dataSaved = false;  
  employeeForm: any;  
  allEmployees: any; 
  employeeIdUpdate : number ;  
  massage : string; 
  isDataAvailable: boolean= false;
  constructor(private formbulider: FormBuilder, private employeeService:EmployeeService) { }

  ngOnInit() {
    // this.employeeForm = this.formbulider.group({  
    //   EmpName: ['', [Validators.required]],  
    //   DateOfBirth: ['', [Validators.required]],  
    //   EmailId: ['', [Validators.required]],  
    //   Gender: ['', [Validators.required]],  
    //   Address: ['', [Validators.required]],  
    //   PinCode: ['', [Validators.required]],
    // });  
    this.loadAllEmployees();
  }
  loadAllEmployees() {  
    this.employeeService.getAllEmployee().subscribe((res:any)=> {
    if(res){
    this.allEmployees = res;
    this.isDataAvailable = true;
    }
    else
    {
      this.isDataAvailable = false;
    }
  }
  );  
  }  
  onFormSubmit() {  
    this.dataSaved = false;  
    const employee = this.employeeForm.value;  
    this.CreateEmployee(employee);  
    this.employeeForm.reset();  
  } 
  loadEmployeeToEdit(employeeId: number) {  
    this.employeeService.getEmployeeById(employeeId).subscribe(response=> {  
      if(response){
      this.dataSaved = false;  
      this.employeeIdUpdate = response.EmpId;  
      this.employeeForm.controls['EmpName'].setValue(response.EmpName);  
     this.employeeForm.controls['DateOfBirth'].setValue(response.DateOfBirth);  
      this.employeeForm.controls['EmailId'].setValue(response.EmailId);  
      this.employeeForm.controls['Gender'].setValue(response.Gender);  
      this.employeeForm.controls['Address'].setValue(response.Address);  
      this.employeeForm.controls['PinCode'].setValue(response.PinCode); 
      } 
    });  
  
  } 

  CreateEmployee(employee: Employee) {  
    if (this.employeeIdUpdate == 0) {  
      this.employeeService.createEmployee(employee).subscribe(  
        () => {  
          this.dataSaved = true;  
          this.massage = 'Record saved Successfully';  
          this.loadAllEmployees();  
          this.employeeIdUpdate = 0;  
          this.employeeForm.reset();  
        }  
      );  
    } else {  
      employee.EmpId = this.employeeIdUpdate;  
      this.employeeService.updateEmployee(employee).subscribe(() => {  
        this.dataSaved = true;  
        this.massage = 'Record Updated Successfully';  
        this.loadAllEmployees();  
        this.employeeIdUpdate = 0;  
        this.employeeForm.reset();  
      });  
    }  
  }   

  deleteEmployee(employeeId: number) {  
    if (confirm("Are you sure you want to delete this ?")) {   
    this.employeeService.deleteEmployeeById(employeeId).subscribe(() => {  
      this.dataSaved = true;  
      this.massage = 'Record Deleted Succefully';  
      this.loadAllEmployees();  
      this.employeeIdUpdate = 0;  
      this.employeeForm.reset();  
  
    });  
  }  
}  

resetForm() {  
  this.employeeForm.reset();  
   this.dataSaved = false;  
}  

}
